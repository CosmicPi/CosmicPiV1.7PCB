We corrected the foorptins for the MAX1983 since it has 12 pins not 16!
