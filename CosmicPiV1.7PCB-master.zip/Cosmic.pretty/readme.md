Here are the unique footprints we made in kicad.
